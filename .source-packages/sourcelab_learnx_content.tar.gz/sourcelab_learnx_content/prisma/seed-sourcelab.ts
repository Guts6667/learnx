import 'dotenv/config';

import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

import {
  SAMPLE_PROGRAM_SEED_TRANSACTION_OPTIONS,
  createSeedProgramRepository,
  seedSampleProgram,
  type SampleSeed,
} from './seed';

const SOURCE_FILES = [
  'seed/ingenieur-logiciel-production-sourcelab-program.json',
  'seed/ai-product-engineer-sourcelab-program.json',
] as const;

async function readSeed(relativePath: string): Promise<SampleSeed> {
  const raw = await readFile(resolve(process.cwd(), relativePath), 'utf8');
  return JSON.parse(raw) as SampleSeed;
}

function getAdminEmail(): string {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  if (!email) {
    throw new Error('ADMIN_EMAIL is required to import SourceLab programs.');
  }
  return email;
}

async function main(): Promise<void> {
  const { prisma } = await import('../src/server/prisma');
  try {
    const owner = await prisma.user.findUnique({
      where: { email: getAdminEmail() },
      select: { id: true },
    });
    if (!owner) {
      throw new Error('No LearnX account matches ADMIN_EMAIL.');
    }

    const seeds = await Promise.all(SOURCE_FILES.map(readSeed));
    await prisma.$transaction(async (transaction) => {
      const repository = createSeedProgramRepository(transaction);
      for (const seed of seeds) {
        await seedSampleProgram(
          repository,
          owner.id,
          seed.program,
          seed.conceptAssessmentBanks,
        );
      }
    }, SAMPLE_PROGRAM_SEED_TRANSACTION_OPTIONS);

    console.info(
      `SourceLab programs imported: ${seeds
        .map(({ program }) => program.slug)
        .join(', ')}.`,
    );
  } finally {
    await prisma.$disconnect();
  }
}

void main().catch((error: unknown) => {
  console.error(error);
  process.exitCode = 1;
});

import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

type Json = Record<string, unknown>;

const PROGRAM_FILES = [
  'seed/ingenieur-logiciel-production-sourcelab-program.json',
  'seed/ai-product-engineer-sourcelab-program.json',
] as const;

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

async function readJson(path: string): Promise<Json> {
  return JSON.parse(await readFile(resolve(process.cwd(), path), 'utf8')) as Json;
}

function asArray(value: unknown, label: string): Json[] {
  assert(Array.isArray(value), `${label} must be an array.`);
  return value as Json[];
}

function asString(value: unknown, label: string): string {
  assert(typeof value === 'string' && value.length > 0, `${label} must be a string.`);
  return value;
}

function validateLesson(
  lesson: Json,
  banksByLesson: Map<string, Json[]>,
  path: string,
): void {
  const lessonSlug = asString(lesson.slug, `${path}.slug`);
  const content = asArray(lesson.contentBlocks, `${path}.contentBlocks`);
  const resources = asArray(lesson.resources, `${path}.resources`);
  const concepts = asArray(lesson.concepts, `${path}.concepts`);
  const tasks = asArray(lesson.tasks, `${path}.tasks`);
  const quizzes = asArray(lesson.quizzes, `${path}.quizzes`);
  const sequence = asArray(lesson.sequence, `${path}.sequence`);

  const resourceKeys = new Set(resources.map((item) => asString(item.key, 'resource.key')));
  for (const block of content) {
    const blockContent = block.content as Json;
    const sourceKeys = blockContent.sourceKeys;
    assert(Array.isArray(sourceKeys), `${path}: content.sourceKeys must be an array.`);
    for (const key of sourceKeys) {
      assert(typeof key === 'string', `${path}: content source key must be a string.`);
      assert(resourceKeys.has(key), `${path}: unknown content source ${key}.`);
    }
  }

  const targets = new Set<string>();
  for (const block of content) targets.add(`CONTENT:${asString(block.key, 'content.key')}`);
  for (const resource of resources) targets.add(`RESOURCE:${asString(resource.key, 'resource.key')}`);
  for (const task of tasks) {
    const type = asString(task.type, 'task.type');
    const kind = ['writing', 'practice', 'reflection', 'project'].includes(type)
      ? 'EXERCISE'
      : 'TASK';
    targets.add(`${kind}:${asString(task.key, 'task.key')}`);
  }
  for (const concept of concepts) {
    const assessment = concept.assessment as Json;
    assert(assessment, `${path}: required concept lacks assessment.`);
    targets.add(`CONCEPT_ASSESSMENT:${asString(assessment.key, 'assessment.key')}`);
  }
  for (const item of quizzes) targets.add(`QUIZ:${asString(item.key, 'quiz.key')}`);

  const seen = new Set<string>();
  for (const item of sequence) {
    const ref = `${asString(item.kind, 'sequence.kind')}:${asString(item.key, 'sequence.key')}`;
    assert(targets.has(ref), `${path}: sequence targets unknown ${ref}.`);
    assert(!seen.has(ref), `${path}: sequence duplicates ${ref}.`);
    seen.add(ref);
  }
  assert(
    [...targets].every((target) => seen.has(target)),
    `${path}: sequence does not include every authored item.`,
  );

  const banks = banksByLesson.get(lessonSlug) ?? [];
  assert(banks.length === concepts.length, `${path}: missing concept banks.`);
  for (const concept of concepts) {
    const assessment = concept.assessment as Json;
    const bank = banks.find(
      (item) => item.conceptSlug === concept.slug,
    );
    assert(bank, `${path}: no bank for ${String(concept.slug)}.`);
    assert(
      asArray(bank.questions, 'bank.questions').length === assessment.questionCount,
      `${path}: question count mismatch for ${String(concept.slug)}.`,
    );
  }
}

async function validateProgram(file: string): Promise<void> {
  const seed = await readJson(file);
  const program = seed.program as Json;
  assert(program, `${file}: missing program.`);
  const groups = asArray(seed.conceptAssessmentBanks, `${file}.conceptAssessmentBanks`);
  const banksByLesson = new Map<string, Json[]>();
  for (const group of groups) {
    banksByLesson.set(
      asString(group.lessonSlug, 'group.lessonSlug'),
      asArray(group.assessmentBanks, 'group.assessmentBanks'),
    );
  }
  for (const stage of asArray(program.stages, `${file}.program.stages`)) {
    const assessment = stage.assessment as Json;
    assert(assessment, `${file}: stage lacks assessment.`);
    const rubric = asArray(assessment.rubric, 'stage.assessment.rubric');
    const weight = rubric.reduce((sum, item) => sum + Number(item.weight), 0);
    assert(weight === 100, `${file}: stage rubric weight is ${weight}, expected 100.`);
    for (const module of asArray(stage.modules, 'stage.modules')) {
      for (const lesson of asArray(module.lessons, 'module.lessons')) {
        validateLesson(
          lesson,
          banksByLesson,
          `${file}:${String(stage.slug)}/${String(module.slug)}/${String(lesson.slug)}`,
        );
      }
    }
  }
  console.info(`Validated ${asString(program.slug, 'program.slug')}.`);
}

for (const file of PROGRAM_FILES) {
  await validateProgram(file);
}
